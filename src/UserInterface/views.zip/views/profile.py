"""User Profile view for AutoRBI application."""

import customtkinter as ctk
from tkinter import messagebox
from datetime import datetime


class ProfileView:
    """Handles the User Profile interface."""

    def __init__(self, parent: ctk.CTk, controller):
        self.parent = parent
        self.controller = controller

    def show(self) -> None:
        """Display the Profile interface."""
        # Clear existing widgets
        for widget in self.parent.winfo_children():
            widget.destroy()

        # Get current user data from controller
        user = self.controller.current_user

        # Extract user info with fallbacks
        full_name = user.get("full_name") or user.get("username") or "Unknown User"
        username = user.get("username") or "unknown"
        role = user.get("role") or "User"
        email = user.get("email") or f"{username}@company.com"

        # Format member since date (if available from user object)
        # For now, use current year as placeholder
        member_since = user.get("created_at")
        if member_since:
            if isinstance(member_since, datetime):
                member_since = member_since.strftime("%b %Y")
            elif isinstance(member_since, str):
                try:
                    dt = datetime.fromisoformat(member_since)
                    member_since = dt.strftime("%b %Y")
                except:
                    member_since = "N/A"
        else:
            member_since = "N/A"

        # Root frame
        root_frame = ctk.CTkFrame(self.parent, corner_radius=0, fg_color="transparent")
        root_frame.pack(expand=True, fill="both", padx=32, pady=24)

        root_frame.grid_rowconfigure(1, weight=1)
        root_frame.grid_columnconfigure(0, weight=1)

        # Header
        header = ctk.CTkFrame(root_frame, fg_color="transparent")
        header.grid(row=0, column=0, sticky="ew")
        header.grid_columnconfigure(0, weight=1)

        back_btn = ctk.CTkButton(
            header,
            text="← Back",
            command=self.controller.show_main_menu,
            width=120,
            height=32,
            font=("Segoe UI", 10),
            fg_color="transparent",
            text_color=("gray20", "gray90"),
            hover_color=("gray85", "gray30"),
            border_width=0,
        )
        back_btn.grid(row=0, column=0, sticky="w")

        title_label = ctk.CTkLabel(
            header,
            text="User Profile",
            font=("Segoe UI", 24, "bold"),
        )
        title_label.grid(row=0, column=1, sticky="e")

        # Main content
        main_frame = ctk.CTkFrame(
            root_frame,
            corner_radius=18,
            border_width=1,
            border_color=("gray80", "gray25"),
        )
        main_frame.grid(row=1, column=0, sticky="nsew", pady=(12, 0))

        scroll = ctk.CTkScrollableFrame(main_frame, fg_color="transparent")
        scroll.pack(expand=True, fill="both", padx=24, pady=24)

        # Avatar/Profile section
        profile_section = ctk.CTkFrame(scroll, fg_color="transparent")
        profile_section.pack(fill="x", pady=(0, 24))

        # Avatar placeholder - shows first letter of name
        avatar_frame = ctk.CTkFrame(
            profile_section,
            width=120,
            height=120,
            corner_radius=60,
            fg_color=("gray80", "gray30"),
        )
        avatar_frame.pack(pady=(0, 16))

        # Get initials for avatar
        initials = self._get_initials(full_name)

        avatar_label = ctk.CTkLabel(
            avatar_frame,
            text=initials,
            font=("Segoe UI", 36, "bold"),
            text_color=("gray40", "gray70"),
        )
        avatar_label.place(relx=0.5, rely=0.5, anchor="center")

        # User info - Full name
        username_label = ctk.CTkLabel(
            profile_section,
            text=full_name,
            font=("Segoe UI", 20, "bold"),
        )
        username_label.pack(pady=(0, 4))

        # Role badge
        role_color = "#3498db" if role == "Admin" else "#27ae60"
        role_label = ctk.CTkLabel(
            profile_section,
            text=role,
            font=("Segoe UI", 12, "bold"),
            text_color=role_color,
        )
        role_label.pack()

        # Profile details
        details_frame = ctk.CTkFrame(scroll, fg_color="transparent")
        details_frame.pack(fill="x", pady=(0, 24))

        section_title = ctk.CTkLabel(
            details_frame,
            text="Profile Information",
            font=("Segoe UI", 16, "bold"),
        )
        section_title.pack(anchor="w", pady=(0, 16))

        # Profile fields - using real data
        fields = [
            ("Username", username),
            ("Full Name", full_name),
            ("Email", email),
            ("Role", role),
            ("Member Since", member_since),
        ]

        for field_label, field_value in fields:
            field_frame = ctk.CTkFrame(details_frame, fg_color="transparent")
            field_frame.pack(fill="x", pady=(0, 12))

            label = ctk.CTkLabel(
                field_frame,
                text=f"{field_label}:",
                font=("Segoe UI", 11, "bold"),
                width=120,
                anchor="w",
            )
            label.pack(side="left", padx=(0, 12))

            value = ctk.CTkLabel(
                field_frame,
                text=field_value,
                font=("Segoe UI", 11),
                text_color=("gray40", "gray80"),
            )
            value.pack(side="left")

        # Edit button
        edit_btn = ctk.CTkButton(
            scroll,
            text="Edit Profile",
            command=self._show_edit_dialog,
            height=40,
            font=("Segoe UI", 12, "bold"),
        )
        edit_btn.pack(pady=(20, 0))

    def _get_initials(self, name: str) -> str:
        """Get initials from full name."""
        if not name:
            return "?"

        parts = name.strip().split()
        if len(parts) >= 2:
            return (parts[0][0] + parts[-1][0]).upper()
        elif len(parts) == 1:
            return parts[0][0].upper()
        return "?"

    def _show_edit_dialog(self) -> None:
        """Show edit profile dialog."""
        # For now, show info message
        # Later, this will open an edit dialog
        messagebox.showinfo(
            "Edit Profile",
            "Profile editing will be available in a future update.\n\n"
            "Contact your administrator to update your information.",
        )
