# define the Base class that all SQLAlchemy models will inherit

from sqlalchemy.orm import declarative_base

Base = declarative_base()
